:mod:`ikpy.chain` module
----------------------------------------

.. automodule:: ikpy.chain
    :members:
    :undoc-members:
    :show-inheritance:
