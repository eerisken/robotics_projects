Welcome to IKPy's documentation!
====================================================

Here you can find the documentation of the Inverse Kinematics API.

If you search getting started guides and tutorials, go to the Github repository_.

.. _repository: https://github.com/Phylliade/ikpy


.. toctree::
   :maxdepth: 2

   ikpy


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
