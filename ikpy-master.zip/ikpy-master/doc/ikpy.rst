:mod:`ikpy` package
================================

.. toctree::
   :maxdepth: 2

   chain
   link
   inverse_kinematics
   utils/geometry
   urdf/URDF.rst
   urdf/utils

